/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.testepanelprint;

import java.awt.Container;
import javax.swing.JFrame;

/**
 *
 * @author 182310022
 */
public class TestePanelPrint extends JFrame{

    public TestePanelPrint(){
        Container c = getContentPane();
        c.add(new tester());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(720, 1280);
        setVisible(true);
        
        
    }
    public static void main(String[] args) {
        new TestePanelPrint();
        
       // System.out.println((ano.length));
       calendario();
    }
        public static void calendario(){
            String[] ano = new String[10];
            int anoatual = 2024;
        for(int i =0;i<10;i++){
            anoatual = anoatual- 1;
            ano[i] =  Integer.toString(anoatual);
            System.out.println(anoatual);
        }
        for(int i =0;i<10;i++){
            System.out.println(ano[i]+ "\n");
            
        }
        
    }
}
